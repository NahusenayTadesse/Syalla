import{l as o,k as r}from"../chunks/nJyKhzr9.js";export{o as load_css,r as start};
