import{l as o,k as r}from"../chunks/CJygYTv7.js";export{o as load_css,r as start};
