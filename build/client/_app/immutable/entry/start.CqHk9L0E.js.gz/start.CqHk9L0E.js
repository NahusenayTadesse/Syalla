import{l as o,k as r}from"../chunks/CcSbb1ja.js";export{o as load_css,r as start};
