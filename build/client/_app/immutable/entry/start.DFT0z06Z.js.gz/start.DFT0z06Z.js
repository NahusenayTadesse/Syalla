import{l as o,k as r}from"../chunks/DTDQGk8T.js";export{o as load_css,r as start};
