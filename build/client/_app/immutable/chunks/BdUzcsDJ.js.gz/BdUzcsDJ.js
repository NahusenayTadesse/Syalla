import{F as t,G as c,H as h,I as i,J as m}from"./DiNgYI7j.js";function f(n,r,e){c&&h();var o=new m(n);t(()=>{var a=r()??null;o.ensure(a,a&&(s=>e(s,a)))},i)}export{f as c};
