import{s as e,p as r}from"./CJygYTv7.js";const s={get error(){return r.error},get status(){return r.status}};e.updated.check;export{s as p};
