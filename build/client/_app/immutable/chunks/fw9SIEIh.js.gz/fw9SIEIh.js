import{J as t,K as c,L as h,M as i,N as m}from"./BdpL96RW.js";function f(n,r,e){c&&h();var o=new m(n);t(()=>{var a=r()??null;o.ensure(a,a&&(s=>e(s,a)))},i)}export{f as c};
