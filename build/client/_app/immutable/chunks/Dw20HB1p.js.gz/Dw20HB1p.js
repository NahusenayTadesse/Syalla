import"./DsnmJJEf.js";import{t as u,G as P,H as $,U as H,av as z,aw as j,ax as G,ay as U,az as Y,aA as q,aB as C,aa as F,aC as J,aD as b,p as K,a3 as L,a as I,a4 as Q,a2 as V,b as _,c as W,f as y,R as D,d as f,s as v,r as c,S as B,e as g}from"./DiNgYI7j.js";import{s as X,r as Z,i as M,p as A}from"./wqhjZqmC.js";import{I as tt,B as R,b as E,s as et,g as at}from"./CNLxLsD9.js";function rt(d,t,e=!1,r=!1,m=!1){var n=d,s="";u(()=>{var l=H;if(s===(s=t()??"")){P&&$();return}if(l.nodes_start!==null&&(z(l.nodes_start,l.nodes_end),l.nodes_start=l.nodes_end=null),s!==""){if(P){j.data;for(var a=$(),p=a;a!==null&&(a.nodeType!==G||a.data!=="");)p=a,a=U(a);if(a===null)throw Y(),q;C(j,p),n=F(a);return}var o=s+"";e?o=`<svg>${o}</svg>`:r&&(o=`<math>${o}</math>`);var i=J(o);if((e||r)&&(i=b(i)),C(b(i),i.lastChild),e||r)for(;b(i);)n.before(b(i));else n.before(i)}})}function st(d,t){K(t,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let e=Z(t,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M5 12h14"}],["path",{d:"m12 5 7 7-7 7"}]];tt(d,X({name:"arrow-right"},()=>e,{get iconNode(){return r},children:(m,n)=>{var s=L(),l=I(s);Q(l,()=>t.children??V),_(m,s)},$$slots:{default:!0}})),W()}var lt=y(`<section class="w-[99vw] p-8 py-16 flex flex-col gap-4 justify-center lg:items-center items-start
isolate  ring-white/5 ring-1 bg-opacity-white-10 bg-white/0 shadow-sm shadow-white/20
          backdrop-blur-lg bg-cover bg-[url(/images/light5.png)] bg-center
"><p> </p> <h2 class="lg:text-center text-start"><!></h2> <div class="flex lg:flex-row flex-col gap-2 justify-center items-center w-full"><!> <!></div> <p class="text-gray-1 !lg:text-[16px] text-[14px]!"> </p></section>`);function ht(d,t){var e=lt(),r=f(e),m=f(r,!0);c(r);var n=v(r,2),s=f(n);rt(s,()=>t.title),c(n);var l=v(n,2),a=f(l);R(a,{get href(){return t.href1},target:"_blank",get class(){return`${E} lg:w-auto w-full`},children:(h,x)=>{B();var w=D();u(()=>g(w,t.btn1)),_(h,w)},$$slots:{default:!0}});var p=v(a,2);{var o=h=>{R(h,{variant:"outline",get href(){return t.href2},get class(){return`${E} lg:w-auto w-full text-gray-1`},children:(x,w)=>{B();var k=D();u(()=>g(k,t.btn2)),_(x,k)},$$slots:{default:!0}})};M(p,h=>{t.btn2!==""&&h(o)})}c(l);var i=v(l,2),N=f(i,!0);c(i),c(e),u(()=>{g(m,t.call),g(N,t.para)}),_(d,e)}var nt=y('<span><img src="/icons/heroAi.svg" alt="icons"/> </span>');function it(d,t){var e=nt(),r=v(f(e));c(e),u(()=>{et(e,1,`inline-flex items-center justify-center lg:text-[12px] text-[16px] flex-row gap-3 px-4 
        py-1 rounded-full ${at} `),g(r,` ${t.content??""}`)}),_(d,e)}var ot=y(" <!>",1),ft=y('<div class="flex flex-col gap-4"><div class="lg:max-w-auto w-full"><!></div> <h2> </h2> <p class="text-gray-1 lg:w-1/2 w-full"> </p> <!></div>');function ut(d,t){let e=A(t,"btn",3,!1),r=A(t,"btnName",3,""),m=A(t,"href",3,"");var n=ft(),s=f(n),l=f(s);it(l,{get content(){return t.content}}),c(s);var a=v(s,2),p=f(a,!0);c(a);var o=v(a,2),i=f(o,!0);c(o);var N=v(o,2);{var h=x=>{R(x,{get href(){return m()},class:"bg-white text-black w-xs",target:"_blank",children:(w,k)=>{B();var T=ot(),O=I(T),S=v(O);st(S,{}),u(()=>g(O,`${r()??""} `)),_(w,T)},$$slots:{default:!0}})};M(N,x=>{e()&&x(h)})}c(n),u(()=>{g(p,t.title),g(i,t.para)}),_(d,n)}export{st as A,ht as B,ut as S,it as T};
