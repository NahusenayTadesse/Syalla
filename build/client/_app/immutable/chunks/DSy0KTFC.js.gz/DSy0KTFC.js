import"./DsnmJJEf.js";import{P as u,K as I,L as O,ac as H,al as q,am as $,an as F,ao as G,ap as K,aq as L,ar as j,a1 as Q,as as U,at as b,R as V,S as W,T as M,U as Y,V as z,D as _,W as J,B as y,E as f,H as c,F as v,G as B,I as A,Q as g}from"./BdpL96RW.js";import{s as X,r as Z,i as S,p as T}from"./CpZ3wE_r.js";import{I as tt,B as P,b as D,s as et,g as at}from"./Bq75gctd.js";function rt(d,t,e=!1,r=!1,p=!1){var n=d,s="";u(()=>{var l=H;if(s===(s=t()??"")){I&&O();return}if(l.nodes_start!==null&&(q(l.nodes_start,l.nodes_end),l.nodes_start=l.nodes_end=null),s!==""){if(I){$.data;for(var a=O(),m=a;a!==null&&(a.nodeType!==F||a.data!=="");)m=a,a=G(a);if(a===null)throw K(),L;j($,m),n=Q(a);return}var o=s+"";e?o=`<svg>${o}</svg>`:r&&(o=`<math>${o}</math>`);var i=U(o);if((e||r)&&(i=b(i)),j(b(i),i.lastChild),e||r)for(;b(i);)n.before(b(i));else n.before(i)}})}function st(d,t){V(t,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let e=Z(t,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M5 12h14"}],["path",{d:"m12 5 7 7-7 7"}]];tt(d,X({name:"arrow-right"},()=>e,{get iconNode(){return r},children:(p,n)=>{var s=W(),l=M(s);Y(l,()=>t.children??z),_(p,s)},$$slots:{default:!0}})),J()}var lt=y(`<section class="w-[99vw] p-8 py-16 flex flex-col gap-4 justify-center lg:items-center items-start
isolate  ring-white/5 ring-1 bg-opacity-white-10 bg-white/0 shadow-sm shadow-white/20
          backdrop-blur-lg bg-cover bg-[url(/images/light5.png)] bg-center
"><p> </p> <h2 class="lg:text-center text-start"><!></h2> <div class="flex lg:flex-row flex-col gap-2 justify-center items-center w-full"><!> <!></div> <p class="text-gray-1 !lg:text-[16px] !text-[14px]"> </p></section>`);function ht(d,t){var e=lt(),r=f(e),p=f(r,!0);c(r);var n=v(r,2),s=f(n);rt(s,()=>t.title),c(n);var l=v(n,2),a=f(l);P(a,{get href(){return t.href1},target:"_blank",get class(){return`${D} lg:w-auto w-full`},children:(h,x)=>{B();var w=A();u(()=>g(w,t.btn1)),_(h,w)},$$slots:{default:!0}});var m=v(a,2);{var o=h=>{P(h,{variant:"outline",get href(){return t.href2},get class(){return`${D} lg:w-auto w-full text-gray-1`},children:(x,w)=>{B();var k=A();u(()=>g(k,t.btn2)),_(x,k)},$$slots:{default:!0}})};S(m,h=>{t.btn2!==""&&h(o)})}c(l);var i=v(l,2),N=f(i,!0);c(i),c(e),u(()=>{g(p,t.call),g(N,t.para)}),_(d,e)}var nt=y('<span><img src="/icons/heroAi.svg" alt="icons"/> </span>');function it(d,t){var e=nt(),r=v(f(e));c(e),u(()=>{et(e,1,`inline-flex items-center justify-center lg:text-[12px] text-[16px] flex-row gap-[12px] px-[16px] 
        py-[4px] rounded-full ${at} `),g(r,` ${t.content??""}`)}),_(d,e)}var ot=y(" <!>",1),ft=y('<div class="flex flex-col gap-4"><div class="lg:max-w-auto w-full"><!></div> <h2> </h2> <p class="text-gray-1 lg:w-1/2 w-full"> </p> <!></div>');function ut(d,t){let e=T(t,"btn",3,!1),r=T(t,"btnName",3,""),p=T(t,"href",3,"");var n=ft(),s=f(n),l=f(s);it(l,{get content(){return t.content}}),c(s);var a=v(s,2),m=f(a,!0);c(a);var o=v(a,2),i=f(o,!0);c(o);var N=v(o,2);{var h=x=>{P(x,{get href(){return p()},class:"bg-white text-black w-xs",target:"_blank",children:(w,k)=>{B();var R=ot(),E=M(R),C=v(E);st(C,{}),u(()=>g(E,`${r()??""} `)),_(w,R)},$$slots:{default:!0}})};S(N,x=>{e()&&x(h)})}c(n),u(()=>{g(m,t.title),g(i,t.para)}),_(d,n)}export{ht as B,ut as S,it as T};
