import{B as t,C as c,D as h,E as i,F as m}from"./CLwWOwFo.js";function E(n,r,e){c&&h();var o=new m(n);t(()=>{var a=r()??null;o.ensure(a,a&&(s=>e(s,a)))},i)}export{E as c};
