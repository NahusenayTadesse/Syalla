import"../chunks/DsnmJJEf.js";import{p as N,f as b,t as K,b as d,c as R,s as x,d as w,r as _,O as c,a5 as Me,e as Y,S as oe,a6 as Te,a3 as k,a as m,a4 as $,a2 as I,aE as z,ai as C,aF as M,aH as pe,R as _e,ae as Ee,bn as Je,ag as Qe,u as Xe,T as Ye,$ as Ge}from"../chunks/DiNgYI7j.js";import{s as L,r as D,p as v,i as U,b as Be,a as Ze,c as et}from"../chunks/wqhjZqmC.js";import{e as ue,i as he,a as ne,I as ge,c as ie,f as Se,T as tt,B as be,b as xe,j as rt,s as st,t as ot,k as nt}from"../chunks/CNLxLsD9.js";import{t as at,a as it}from"../chunks/B9-88-1d.js";import"../chunks/ChmF6P2E.js";import{i as ze,p as lt}from"../chunks/D3pk-pO7.js";import{c as ae}from"../chunks/BdUzcsDJ.js";import{C as ct,k as O,w as dt,c as ut,l as ht,a as ve,S as Ue,o as He,d as ft,b as fe,j as me,m as H,n as X}from"../chunks/DjetFALj.js";import{P as Ie,o as pt,F as gt,E as vt,D as mt,T as yt,S as De,a as _t,n as bt}from"../chunks/DDPZXfnK.js";import{o as xt,a as wt}from"../chunks/awTmE6os.js";const we=(s,e,t)=>{let r=Me(()=>Te(e?.(),"")),o=Me(()=>Te(t?.(),()=>[{name:"",href:""}],!0));var a=Ct(),n=w(a),l=w(n,!0);_(n);var h=x(n,2);ue(h,1,()=>c(o),he,(g,P)=>{var y=Pt(),f=w(y,!0);_(y),K(()=>{ne(y,"href",c(P).href),Y(f,c(P).name)}),d(g,y)}),_(a),K(()=>Y(l,c(r))),d(s,a)};var Pt=b('<a class="text-gray-1 hover:scale-105 duration-300 transition-all ease-in-out"> </a>'),Ct=b('<div class="flex flex-col gap-4 w-full"><p class="font-bold"> </p> <!></div>'),St=b(`<footer class="flex flex-col gap-4 justify-center items-center lg:px-[10%] px-8 mt-8 w-full 
bg-linear-to-tr from-[#0F1211] via-[#07171433] to-white/20
"><div class="grid lg:grid-cols-4 grid-cols-1 gap-6 w-full place-items-center items-start p-8 py-16 px-0"><div class="flex flex-col gap-4"><h4 class="text-primary">Syaala LLC</h4> <p class="text-gray-1">Deploy AI models in 60 seconds, From $5 prepaid credits.</p></div> <!> <!> <!></div> <div class="flex lg:flex-row flex-col  lg:justify-between justify-center w-full"><span class="text-gray-1 lg:text-[16px] text-[12px] text-center"> </span> <span class="text-gray-1 lg:text-[16px] text-[12px] text-center">Deploy AI models in seconds, not hours.</span></div></footer>`);function kt(s,e){N(e,!1);const t=[{name:"Features",href:"#"},{name:"Pricing",href:"#"},{name:"Consulting",href:"#"},{name:"Launch Console",href:"#"}],r=[{name:"Documentation",href:"#"},{name:"Quick Start",href:"#"},{name:"API Reference",href:"#"}],o=[{name:"Terms of Service",href:"#"},{name:"Privacy Policy",href:"#"},{name:"Contact Support",href:"#"}];let a=new Date().getFullYear();ze();var n=St(),l=w(n),h=x(w(l),2);we(h,()=>"Platform",()=>t);var g=x(h,2);we(g,()=>"Resources",()=>r);var P=x(g,2);we(P,()=>"Legal",()=>o),_(l);var y=x(l,2),f=w(y),u=w(f);_(f),oe(2),_(y),_(n),K(()=>Y(u,`©${a??""} Syaala LLC. Memphis, TN.`)),d(s,n),R()}function At(s,e){N(e,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=D(e,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335"}],["path",{d:"m9 11 3 3L22 4"}]];ge(s,L({name:"circle-check-big"},()=>t,{get iconNode(){return r},children:(o,a)=>{var n=k(),l=m(n);$(l,()=>e.children??I),d(o,n)},$$slots:{default:!0}})),R()}function Ot(s,e){N(e,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=D(e,["$$slots","$$events","$$legacy"]);const r=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"m15 9-6 6"}],["path",{d:"m9 9 6 6"}]];ge(s,L({name:"circle-x"},()=>t,{get iconNode(){return r},children:(o,a)=>{var n=k(),l=m(n);$(l,()=>e.children??I),d(o,n)},$$slots:{default:!0}})),R()}function $t(s,e){N(e,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=D(e,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M3 5h18"}],["path",{d:"M3 12h18"}],["path",{d:"M3 19h18"}]];ge(s,L({name:"text-align-justify"},()=>t,{get iconNode(){return r},children:(o,a)=>{var n=k(),l=m(n);$(l,()=>e.children??I),d(o,n)},$$slots:{default:!0}})),R()}function Nt(s,e){N(e,!0);/**
 * @license @lucide/svelte v0.544.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */let t=D(e,["$$slots","$$events","$$legacy"]);const r=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];ge(s,L({name:"x"},()=>t,{get iconNode(){return r},children:(o,a)=>{var n=k(),l=m(n);$(l,()=>e.children??I),d(o,n)},$$slots:{default:!0}})),R()}const Rt=ut({component:"dialog",parts:["content","trigger","overlay","title","description","close","cancel","action"]}),G=new ct("Dialog.Root | AlertDialog.Root");class ke{static create(e){const t=G.getOr(null);return G.set(new ke(e,t))}opts;#e=z(null);get triggerNode(){return c(this.#e)}set triggerNode(e){C(this.#e,e,!0)}#t=z(null);get contentNode(){return c(this.#t)}set contentNode(e){C(this.#t,e,!0)}#r=z(null);get overlayNode(){return c(this.#r)}set overlayNode(e){C(this.#r,e,!0)}#s=z(null);get descriptionNode(){return c(this.#s)}set descriptionNode(e){C(this.#s,e,!0)}#o=z(void 0);get contentId(){return c(this.#o)}set contentId(e){C(this.#o,e,!0)}#n=z(void 0);get titleId(){return c(this.#n)}set titleId(e){C(this.#n,e,!0)}#a=z(void 0);get triggerId(){return c(this.#a)}set triggerId(e){C(this.#a,e,!0)}#i=z(void 0);get descriptionId(){return c(this.#i)}set descriptionId(e){C(this.#i,e,!0)}#l=z(null);get cancelNode(){return c(this.#l)}set cancelNode(e){C(this.#l,e,!0)}#c=z(0);get nestedOpenCount(){return c(this.#c)}set nestedOpenCount(e){C(this.#c,e,!0)}depth;parent;contentPresence;overlayPresence;constructor(e,t){this.opts=e,this.parent=t,this.depth=t?t.depth+1:0,this.handleOpen=this.handleOpen.bind(this),this.handleClose=this.handleClose.bind(this),this.contentPresence=new Ie({ref:O(()=>this.contentNode),open:this.opts.open,enabled:!0,onComplete:()=>{this.opts.onOpenChangeComplete.current(this.opts.open.current)}}),this.overlayPresence=new Ie({ref:O(()=>this.overlayNode),open:this.opts.open,enabled:!0}),dt(()=>this.opts.open.current,r=>{this.parent&&(r?this.parent.incrementNested():this.parent.decrementNested())},{lazy:!0}),pt(()=>{this.opts.open.current&&this.parent?.decrementNested()})}handleOpen(){this.opts.open.current||(this.opts.open.current=!0)}handleClose(){this.opts.open.current&&(this.opts.open.current=!1)}getBitsAttr=e=>Rt.getAttr(e,this.opts.variant.current);incrementNested(){this.nestedOpenCount++,this.parent?.incrementNested()}decrementNested(){this.nestedOpenCount!==0&&(this.nestedOpenCount--,this.parent?.decrementNested())}#d=M(()=>({"data-state":ht(this.opts.open.current)}));get sharedProps(){return c(this.#d)}set sharedProps(e){C(this.#d,e)}}class Ae{static create(e){return new Ae(e,G.get())}opts;root;attachment;constructor(e,t){this.opts=e,this.root=t,this.attachment=ve(this.opts.ref,r=>{this.root.triggerNode=r,this.root.triggerId=r?.id}),this.onclick=this.onclick.bind(this),this.onkeydown=this.onkeydown.bind(this)}onclick(e){this.opts.disabled.current||e.button>0||this.root.handleOpen()}onkeydown(e){this.opts.disabled.current||(e.key===Ue||e.key===He)&&(e.preventDefault(),this.root.handleOpen())}#e=M(()=>({id:this.opts.id.current,"aria-haspopup":"dialog","aria-expanded":ft(this.root.opts.open.current),"aria-controls":this.root.contentId,[this.root.getBitsAttr("trigger")]:"",onkeydown:this.onkeydown,onclick:this.onclick,disabled:this.opts.disabled.current?!0:void 0,...this.root.sharedProps,...this.attachment}));get props(){return c(this.#e)}set props(e){C(this.#e,e)}}class Oe{static create(e){return new Oe(e,G.get())}opts;root;attachment;constructor(e,t){this.opts=e,this.root=t,this.attachment=ve(this.opts.ref),this.onclick=this.onclick.bind(this),this.onkeydown=this.onkeydown.bind(this)}onclick(e){this.opts.disabled.current||e.button>0||this.root.handleClose()}onkeydown(e){this.opts.disabled.current||(e.key===Ue||e.key===He)&&(e.preventDefault(),this.root.handleClose())}#e=M(()=>({id:this.opts.id.current,[this.root.getBitsAttr(this.opts.variant.current)]:"",onclick:this.onclick,onkeydown:this.onkeydown,disabled:this.opts.disabled.current?!0:void 0,tabindex:0,...this.root.sharedProps,...this.attachment}));get props(){return c(this.#e)}set props(e){C(this.#e,e)}}class $e{static create(e){return new $e(e,G.get())}opts;root;attachment;constructor(e,t){this.opts=e,this.root=t,this.attachment=ve(this.opts.ref,r=>{this.root.contentNode=r,this.root.contentId=r?.id})}#e=M(()=>({open:this.root.opts.open.current}));get snippetProps(){return c(this.#e)}set snippetProps(e){C(this.#e,e)}#t=M(()=>({id:this.opts.id.current,role:this.root.opts.variant.current==="alert-dialog"?"alertdialog":"dialog","aria-modal":"true","aria-describedby":this.root.descriptionId,"aria-labelledby":this.root.titleId,[this.root.getBitsAttr("content")]:"",style:{pointerEvents:"auto",outline:this.root.opts.variant.current==="alert-dialog"?"none":void 0,"--bits-dialog-depth":this.root.depth,"--bits-dialog-nested-count":this.root.nestedOpenCount},tabindex:this.root.opts.variant.current==="alert-dialog"?-1:void 0,"data-nested-open":fe(this.root.nestedOpenCount>0),"data-nested":fe(this.root.parent!==null),...this.root.sharedProps,...this.attachment}));get props(){return c(this.#t)}set props(e){C(this.#t,e)}get shouldRender(){return this.root.contentPresence.shouldRender}}class Ne{static create(e){return new Ne(e,G.get())}opts;root;attachment;constructor(e,t){this.opts=e,this.root=t,this.attachment=ve(this.opts.ref,r=>this.root.overlayNode=r)}#e=M(()=>({open:this.root.opts.open.current}));get snippetProps(){return c(this.#e)}set snippetProps(e){C(this.#e,e)}#t=M(()=>({id:this.opts.id.current,[this.root.getBitsAttr("overlay")]:"",style:{pointerEvents:"auto","--bits-dialog-depth":this.root.depth,"--bits-dialog-nested-count":this.root.nestedOpenCount},"data-nested-open":fe(this.root.nestedOpenCount>0),"data-nested":fe(this.root.parent!==null),...this.root.sharedProps,...this.attachment}));get props(){return c(this.#t)}set props(e){C(this.#t,e)}get shouldRender(){return this.root.overlayPresence.shouldRender}}var Ft=b("<div><!></div>");function Mt(s,e){const t=pe();N(e,!0);let r=v(e,"id",19,()=>me(t)),o=v(e,"forceMount",3,!1),a=v(e,"ref",15,null),n=D(e,["$$slots","$$events","$$legacy","id","forceMount","child","children","ref"]);const l=Ne.create({id:O(()=>r()),ref:O(()=>a(),f=>a(f))}),h=M(()=>H(n,l.props));var g=k(),P=m(g);{var y=f=>{var u=k(),i=m(u);{var p=S=>{var T=k(),A=m(T);{let F=M(()=>({props:H(c(h)),...l.snippetProps}));$(A,()=>e.child,()=>c(F))}d(S,T)},j=S=>{var T=Ft();ie(T,F=>({...F}),[()=>H(c(h))]);var A=w(T);$(A,()=>e.children??I,()=>l.snippetProps),_(T),d(S,T)};U(i,S=>{e.child?S(p):S(j,!1)})}d(f,u)};U(P,f=>{(l.shouldRender||o())&&f(y)})}d(s,g),R()}var Tt=b("<button><!></button>");function Et(s,e){const t=pe();N(e,!0);let r=v(e,"id",19,()=>me(t)),o=v(e,"ref",15,null),a=v(e,"disabled",3,!1),n=D(e,["$$slots","$$events","$$legacy","id","ref","children","child","disabled"]);const l=Ae.create({id:O(()=>r()),ref:O(()=>o(),u=>o(u)),disabled:O(()=>!!a())}),h=M(()=>H(n,l.props));var g=k(),P=m(g);{var y=u=>{var i=k(),p=m(i);$(p,()=>e.child,()=>({props:c(h)})),d(u,i)},f=u=>{var i=Tt();ie(i,()=>({...c(h)}));var p=w(i);$(p,()=>e.children??I),_(i),d(u,i)};U(P,u=>{e.child?u(y):u(f,!1)})}d(s,g),R()}function It(s,e){N(e,!0);let t=v(e,"open",15,!1),r=v(e,"onOpenChange",3,X),o=v(e,"onOpenChangeComplete",3,X);ke.create({variant:O(()=>"dialog"),open:O(()=>t(),l=>{t(l),r()(l)}),onOpenChangeComplete:O(()=>o())});var a=k(),n=m(a);$(n,()=>e.children??I),d(s,a),R()}var Dt=b("<button><!></button>");function jt(s,e){const t=pe();N(e,!0);let r=v(e,"id",19,()=>me(t)),o=v(e,"ref",15,null),a=v(e,"disabled",3,!1),n=D(e,["$$slots","$$events","$$legacy","children","child","id","ref","disabled"]);const l=Oe.create({variant:O(()=>"close"),id:O(()=>r()),ref:O(()=>o(),u=>o(u)),disabled:O(()=>!!a())}),h=M(()=>H(n,l.props));var g=k(),P=m(g);{var y=u=>{var i=k(),p=m(i);$(p,()=>e.child,()=>({props:c(h)})),d(u,i)},f=u=>{var i=Dt();ie(i,()=>({...c(h)}));var p=w(i);$(p,()=>e.children??I),_(i),d(u,i)};U(P,u=>{e.child?u(y):u(f,!1)})}d(s,g),R()}var Lt=b("<!> <!>",1),Bt=b("<!> <div><!></div>",1);function zt(s,e){const t=pe();N(e,!0);let r=v(e,"id",19,()=>me(t)),o=v(e,"ref",15,null),a=v(e,"forceMount",3,!1),n=v(e,"onCloseAutoFocus",3,X),l=v(e,"onOpenAutoFocus",3,X),h=v(e,"onEscapeKeydown",3,X),g=v(e,"onInteractOutside",3,X),P=v(e,"trapFocus",3,!0),y=v(e,"preventScroll",3,!0),f=v(e,"restoreScrollDelay",3,null),u=D(e,["$$slots","$$events","$$legacy","id","children","child","ref","forceMount","onCloseAutoFocus","onOpenAutoFocus","onEscapeKeydown","onInteractOutside","trapFocus","preventScroll","restoreScrollDelay"]);const i=$e.create({id:O(()=>r()),ref:O(()=>o(),A=>o(A))}),p=M(()=>H(u,i.props));var j=k(),S=m(j);{var T=A=>{gt(A,{get ref(){return i.opts.ref},loop:!0,get trapFocus(){return P()},get enabled(){return i.root.opts.open.current},get onOpenAutoFocus(){return l()},get onCloseAutoFocus(){return n()},focusScope:(W,q)=>{let J=()=>q?.().props;vt(W,L(()=>c(p),{get enabled(){return i.root.opts.open.current},get ref(){return i.opts.ref},onEscapeKeydown:B=>{h()(B),!B.defaultPrevented&&i.root.handleClose()},children:(B,Z)=>{mt(B,L(()=>c(p),{get ref(){return i.opts.ref},get enabled(){return i.root.opts.open.current},onInteractOutside:E=>{g()(E),!E.defaultPrevented&&i.root.handleClose()},children:(E,le)=>{yt(E,L(()=>c(p),{get ref(){return i.opts.ref},get enabled(){return i.root.opts.open.current},children:(Ke,_r)=>{var Fe=k(),Ve=m(Fe);{var We=Q=>{var ee=Lt(),te=m(ee);{var re=V=>{De(V,{get preventScroll(){return y()},get restoreScrollDelay(){return f()}})};U(te,V=>{i.root.opts.open.current&&V(re)})}var ye=x(te,2);{let V=M(()=>({props:H(c(p),J()),...i.snippetProps}));$(ye,()=>e.child,()=>c(V))}d(Q,ee)},qe=Q=>{var ee=Bt(),te=m(ee);De(te,{get preventScroll(){return y()}});var re=x(te,2);ie(re,V=>({...V}),[()=>H(c(p),J())]);var ye=w(re);$(ye,()=>e.children??I),_(re),d(Q,ee)};U(Ve,Q=>{e.child?Q(We):Q(qe,!1)})}d(Ke,Fe)},$$slots:{default:!0}}))},$$slots:{default:!0}}))},$$slots:{default:!0}}))},$$slots:{focusScope:!0}})};U(S,A=>{(i.shouldRender||a())&&A(T)})}d(s,j),R()}function Ut(s,e){N(e,!0);let t=v(e,"ref",15,null),r=D(e,["$$slots","$$events","$$legacy","ref"]);var o=k(),a=m(o);ae(a,()=>Et,(n,l)=>{l(n,L({"data-slot":"sheet-trigger"},()=>r,{get ref(){return t()},set ref(h){t(h)}}))}),d(s,o),R()}function Ht(s,e){N(e,!0);let t=v(e,"ref",15,null),r=D(e,["$$slots","$$events","$$legacy","ref","class"]);var o=k(),a=m(o);{let n=M(()=>Se("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",e.class));ae(a,()=>Mt,(l,h)=>{h(l,L({"data-slot":"sheet-overlay",get class(){return c(n)}},()=>r,{get ref(){return t()},set ref(g){t(g)}}))})}d(s,o),R()}const Kt=tt({base:"bg-background data-[state=open]:animate-in data-[state=closed]:animate-out fixed z-50 flex flex-col gap-4 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500",variants:{side:{top:"data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top inset-x-0 top-0 h-auto border-b",bottom:"data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom inset-x-0 bottom-0 h-auto border-t",left:"data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left inset-y-0 left-0 h-full w-3/4 border-0 sm:max-w-sm",right:"data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right inset-y-0 right-0 h-full w-3/4 border-0 sm:max-w-sm"}},defaultVariants:{side:"right"}});var Vt=b('<!> <span class="sr-only">Close</span>',1),Wt=b("<!> <!>",1),qt=b("<!> <!>",1);function Jt(s,e){N(e,!0);let t=v(e,"ref",15,null),r=v(e,"side",3,"right"),o=D(e,["$$slots","$$events","$$legacy","ref","class","side","portalProps","children"]);var a=k(),n=m(a);ae(n,()=>_t,(l,h)=>{h(l,L(()=>e.portalProps,{children:(g,P)=>{var y=qt(),f=m(y);Ht(f,{});var u=x(f,2);{let i=M(()=>Se(Kt({side:r()}),e.class));ae(u,()=>zt,(p,j)=>{j(p,L({"data-slot":"sheet-content",get class(){return c(i)}},()=>o,{get ref(){return t()},set ref(S){t(S)},children:(S,T)=>{var A=Wt(),F=m(A);$(F,()=>e.children??I);var W=x(F,2);ae(W,()=>jt,(q,J)=>{J(q,{class:"ring-offset-background focus-visible:ring-ring rounded-xs focus-visible:outline-hidden absolute right-4 top-4 opacity-70 transition-opacity hover:opacity-100 focus-visible:ring-2 focus-visible:ring-offset-2 disabled:pointer-events-none",children:(B,Z)=>{var E=Vt(),le=m(E);Nt(le,{class:"size-4"}),oe(2),d(B,E)},$$slots:{default:!0}})}),d(S,A)},$$slots:{default:!0}}))})}d(g,y)},$$slots:{default:!0}}))}),d(s,a),R()}var Qt=b("<div><!></div>");function Xt(s,e){N(e,!0);let t=v(e,"ref",15,null),r=D(e,["$$slots","$$events","$$legacy","ref","class","children"]);var o=Qt();ie(o,n=>({"data-slot":"sheet-header",class:n,...r}),[()=>Se("flex flex-col gap-1.5 p-4",e.class)]);var a=w(o);$(a,()=>e.children??I),_(o),Be(o,n=>t(n),()=>t()),d(s,o),R()}const Yt=It;var Gt=b('<a class="hover:scale-110 transition-transform ease-in-out duration-300"> </a>'),Zt=b('<li><a class="hover:text-primary transition-transform duration-300 ease-in-out hover:scale-125 text-xl"> </a></li>'),er=b(`<h3 class="text-transparent bg-clip-text
           bg-linear-to-r from-green-1 to-green-2">Syalla</h3> <ul class="flex flex-col gap-2 border-0! justify-center items-start pt-12"></ul>`,1),tr=b("<!> <!>",1),rr=b(`<div class="hidden lg:flex flex-row gap-4 justify-self-center items-center z-2 
justify-between fixed top-4 bg-[#0F1211] p-4 rounded-lg px-6 w-3/5 border-0.5 shadow-lg shadow-white/10 border-white "><div class="flex flex-row gap-16 items-center justify-center"><a class="text-lg font-bold hover:scale-110 transition-transform ease-in-out duration-300" href="/">Syaala</a> <div class="flex flex-row gap-4 items-center justify-center"></div></div> <div class="flex flex-row justify-center items-center gap-4"><!> <!></div></div> <nav class="lg:hidden sticky top-4 z-10 flex flex-row justify-between items-center p-4"><!>  <!></nav>`,1);function sr(s){let e=[{name:"Home",href:"/"},{name:"Colocation",href:"/colocation"},{name:"Pricing",href:"/pricing"}];var t=rr(),r=m(t),o=w(r),a=x(w(o),2);ue(a,5,()=>e,he,(f,u)=>{var i=Gt(),p=w(i,!0);_(i),K(()=>{ne(i,"href",c(u).href),Y(p,c(u).name)}),d(f,i)}),_(a),_(o);var n=x(o,2),l=w(n);be(l,{variant:"outline",href:"/colocation",get class(){return`${xe}  text-gray-1`},children:(f,u)=>{oe();var i=_e("Explore Colocation");d(f,i)},$$slots:{default:!0}});var h=x(l,2);be(h,{get class(){return xe},href:"https://platform.syaala.com/",target:"_blank",children:(f,u)=>{oe();var i=_e("Start Deploying");d(f,i)},$$slots:{default:!0}}),_(n),_(r);var g=x(r,2),P=w(g);Yt(P,{children:(f,u)=>{var i=tr(),p=m(i);Ut(p,{children:(S,T)=>{$t(S,{})},$$slots:{default:!0}});var j=x(p,2);Jt(j,{class:"bg-black/10 backdrop-blur-lg",side:"left",children:(S,T)=>{Xt(S,{class:"flex flex-col pt-8 gap-4",children:(A,F)=>{var W=er(),q=x(m(W),2);ue(q,5,()=>e,he,(J,B)=>{var Z=Zt(),E=w(Z),le=w(E,!0);_(E),_(Z),K(()=>{ne(E,"href",c(B).href),ne(E,"title",c(B).name),Y(le,c(B).name)}),d(J,Z)}),_(q),d(A,W)},$$slots:{default:!0}})},$$slots:{default:!0}}),d(f,i)},$$slots:{default:!0}});var y=x(P,2);be(y,{get class(){return xe},children:(f,u)=>{oe();var i=_e("Start Deploying");d(f,i)},$$slots:{default:!0}}),_(g),d(s,t)}var or=b('<figure class="star svelte-2wwmhl"></figure>'),nr=b('<div class="stars -z-1 h-screen w-screen svelte-2wwmhl"></div>');function ar(s,e){N(e,!1);let t=Ee([]),r=Ee();xt(()=>{C(t,Array.from({length:200},()=>({top:`${100*Math.random()}%`,left:`${100*Math.random()}%`,delay:`${2*Math.random()}s`})))}),ze();var o=nr();ue(o,5,()=>c(t),he,(a,n)=>{var l=or();let h;K(g=>h=rt(l,"",h,g),[()=>({top:c(n).top,left:c(n).left,"animation-delay":c(n).delay})]),d(a,l)}),_(o),Be(o,a=>C(r,a),()=>c(r)),d(s,o),R()}const ir=""+new URL("../../../favicon.png",import.meta.url).href,lr=encodeURIComponent,ce=/^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;function cr(s,e,t){let r=t||{},o=r.encode||lr;if(typeof o!="function")throw new TypeError("option encode is invalid");if(!ce.test(s))throw new TypeError("argument name is invalid");let a=o(e);if(a&&!ce.test(a))throw new TypeError("argument val is invalid");let n=s+"="+a;if(r.maxAge!=null){let l=r.maxAge-0;if(isNaN(l)||!isFinite(l))throw new TypeError("option maxAge is invalid");n+="; Max-Age="+Math.floor(l)}if(r.domain){if(!ce.test(r.domain))throw new TypeError("option domain is invalid");n+="; Domain="+r.domain}if(r.path){if(!ce.test(r.path))throw new TypeError("option path is invalid");n+="; Path="+r.path}if(r.expires){if(typeof r.expires.toUTCString!="function")throw new TypeError("option expires is invalid");n+="; Expires="+r.expires.toUTCString()}if(r.httpOnly&&(n+="; HttpOnly"),r.secure&&(n+="; Secure"),r.sameSite)switch(typeof r.sameSite=="string"?r.sameSite.toLowerCase():r.sameSite){case!0:n+="; SameSite=Strict";break;case"lax":n+="; SameSite=Lax";break;case"strict":n+="; SameSite=Strict";break;case"none":n+="; SameSite=None";break;default:throw new TypeError("option sameSite is invalid")}return n}const dr={clearArray:!1,clearOnNavigate:!0,clearAfterMs:0,flashCookieOptions:{path:"/",maxAge:120,httpOnly:!1,sameSite:"strict"}};function ur(s,e){return{...s,...e,flashCookieOptions:{...s.flashCookieOptions,...e?.flashCookieOptions}}}class je{options;_message;get message(){return this._message}_flashTimeout=0;get flashTimeout(){return this._flashTimeout}constructor(e,t){this.options=t??dr,this._message={subscribe:e.subscribe,set:(r,o)=>e.update(a=>this.update(a,r,o?.concatenateArray??!1)),update:(r,o)=>e.update(a=>this.update(a,r(a),o?.concatenateArray??!1))}}update(e,t,r=!1){return this._flashTimeout&&clearTimeout(this.flashTimeout),r&&Array.isArray(t)&&Array.isArray(e)?e.length>0&&t.length>0&&e[e.length-1]===t[t.length-1]?e:e.concat(t):(t!==void 0&&this.options.clearAfterMs&&(this._flashTimeout=setTimeout(()=>{this.message.set(void 0)},this.options.clearAfterMs)),t)}}class hr{routes=new Map;messageStore;constructor(){this.messageStore=Je(),this.routes.set("",new je(this.messageStore)),wt(()=>{for(const e of this.routes.values())clearTimeout(e.flashTimeout)})}get defaultRoute(){return this.routes.get("")}has(e){return this.routes.has(e)}getFlashMessage(e){return e?this.routes.has(e)?this.routes.get(e):this.getClosestRoute(e):this.defaultRoute}getClosestRoute(e){const t=Array.from(this.routes.keys()).filter(o=>e.includes(o));if(!t.length)return this.defaultRoute;const r=t.reduce((o,a)=>a.length>o.length?a:o);return this.routes.get(r)}createRoute(e,t,r){const o=this.getClosestRoute(e),a=new je(this.messageStore,ur(o.options,r));return a.message.set(t),this.routes.set(e,a),a}}const de="flash",Le=new WeakMap;function Re(s){return"subscribe"in s?Qe(s):s}function se(s,e){let t=Le.get(s);return t||(t=new hr,Le.set(s,t),t.getFlashMessage(Re(s).route.id).message.set(e),fr(s)),t}function fr(s){bt.subscribe(e=>{if(e===null){const t=Ce();if(t!==void 0){const r=se(s).getFlashMessage(Re(s).route.id);r.message.set(t,{concatenateArray:!r.options.clearArray}),Pe(r.options.flashCookieOptions)}}else{const t=e?.to?.route.id;if(t){const r=se(s).getFlashMessage(t);r.options.clearOnNavigate&&e.from?.route.id!=t&&r.message.set(void 0)}}});try{if("subscribe"in s)throw"$app/stores used";Xe(()=>{s.data,s.error,s.form,s.params,s.route,s.state,s.status,s.url;const e=Ce();if(e!==void 0){const t=se(s).getFlashMessage(s.route.id);t.message.set(e,{concatenateArray:!t.options.clearArray}),Pe(t.options.flashCookieOptions)}})}catch{if(!("subscribe"in s))throw new Error("sveltekit-flash-message cannot use Page from $app/state in Svelte 4. Use $app/stores instead.");s.subscribe(r=>{const o=Ce();if(o!==void 0){const a=se(s).getFlashMessage(r.route.id);a.message.set(o,{concatenateArray:!a.options.clearArray}),Pe(a.options.flashCookieOptions)}})}}function pr(s,e){const t=Re(s),r=se(s,t.data.flash);function o(){const g=r.routes.get(h());return g||(e?a():r.getClosestRoute(h()))}function a(){return r.createRoute(h(),l(),e)}const n={route:t.route.id,initialdata:t.data.flash};function l(){return n.initialdata}function h(){return n.route??""}return o()}function gr(s,e){return pr(s,e).message}function Pe(s){document.cookie=cr(de,"",{...s,maxAge:0})}function Ce(){const s=document.cookie;if(!s||!s.includes(de+"="))return;function e(r){const o={};return r?r.split(";").map(a=>a.split("=")).reduce((a,n)=>(a[decodeURIComponent(n[0].trim())]=decodeURIComponent(n[1].trim()),a),o):o}const t=e(s);if(t[de])try{return JSON.parse(t[de])}catch{}}var vr=b('<link rel="icon"/>'),mr=b("<div><!> </div>"),yr=b("<!> <!> <!> <!> <!>",1);function Rr(s,e){N(e,!0);const t=()=>et(a,"$flash",r),[r,o]=Ze(),a=gr(lt,{clearAfterMs:5e3});let n="h-6 w-6";var l=yr();Ye(i=>{var p=vr();Ge.title="Syaala LLC",K(()=>ne(p,"href",ir)),d(i,p)});var h=m(l);{var g=i=>{var p=mr(),j=w(p);{var S=F=>{At(F,{class:n})},T=F=>{Ot(F,{class:n})};U(j,F=>{t().type==="success"?F(S):F(T,!1)})}var A=x(j);_(p),K(()=>{st(p,1,`flex flex-row gap-2 
  ${(t().type==="success"?ot:nt)??""}`),Y(A,` ${t().message??""}`)}),at(3,p,()=>it,()=>({x:20,duration:300})),d(i,p)};U(h,i=>{t()&&i(g)})}var P=x(h,2);sr(P);var y=x(P,2);$(y,()=>e.children??I);var f=x(y,2);kt(f,{});var u=x(f,2);ar(u,{}),d(s,l),R(),o()}export{Rr as component};
